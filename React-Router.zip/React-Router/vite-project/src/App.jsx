import {BrowserRouter, Route, Routes,useParams} from 'react-router-dom';
import Home from './Component/Home'
import About from './Component/About'
import Information from './Component/Information';


const App=()=>{
  const User = () => {
    // const hooks=useParams();
    // console.log ('----------------',hooks);
    const { id } = useParams(); 
    return <div>User ID: {id}</div>;
  };
  
  return(
    <>
   <BrowserRouter>
   <Routes>
    <Route path='/' Component={Home}></Route>
    <Route path='/about' Component={About}></Route>
    <Route path='/info' Component={Information}></Route>
    <Route path='/users/:id' Component={User}></Route>
   
   </Routes>
   
   </BrowserRouter>
    </>
  )
}
export default App