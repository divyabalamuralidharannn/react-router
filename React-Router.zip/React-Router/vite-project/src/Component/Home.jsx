import { Link } from "react-router-dom";
import About from "./About";

const Home=()=>{
  return(

    <>
    <p>Home</p>
    <Link to='/about'>
<button id="abt">About</button>
    </Link>
    <Link to='/info'>

      <button id="info">Information</button>
    </Link>
    </>
  )
}
export default Home;