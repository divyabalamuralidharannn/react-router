const Information=()=>{
  return(
    <>
    <p>Information</p>
    </>
  )
}
export default Information